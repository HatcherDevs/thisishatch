<?php

declare(strict_types=1);

namespace RectorLaravel\Set;

final class LaravelLevelSetList
{
    /**
     * @var string
     */
    public const UP_TO_LARAVEL_51 = __DIR__ . '/../../config/sets/level/up-to-laravel-51.php';

    /**
     * @var string
     */
    public const UP_TO_LARAVEL_52 = __DIR__ . '/../../config/sets/level/up-to-laravel-52.php';

    /**
     * @var string
     */
    public const UP_TO_LARAVEL_53 = __DIR__ . '/../../config/sets/level/up-to-laravel-53.php';

    /**
     * @var string
     */
    public const UP_TO_LARAVEL_54 = __DIR__ . '/../../config/sets/level/up-to-laravel-54.php';

    /**
     * @var string
     */
    public const UP_TO_LARAVEL_55 = __DIR__ . '/../../config/sets/level/up-to-laravel-55.php';

    /**
     * @var string
     */
    public const UP_TO_LARAVEL_56 = __DIR__ . '/../../config/sets/level/up-to-laravel-56.php';

    /**
     * @var string
     */
    public const UP_TO_LARAVEL_57 = __DIR__ . '/../../config/sets/level/up-to-laravel-57.php';

    /**
     * @var string
     */
    public const UP_TO_LARAVEL_58 = __DIR__ . '/../../config/sets/level/up-to-laravel-58.php';

    /**
     * @var string
     */
    public const UP_TO_LARAVEL_60 = __DIR__ . '/../../config/sets/level/up-to-laravel-60.php';

    /**
     * @var string
     */
    public const UP_TO_LARAVEL_70 = __DIR__ . '/../../config/sets/level/up-to-laravel-70.php';

    /**
     * @var string
     */
    public const UP_TO_LARAVEL_80 = __DIR__ . '/../../config/sets/level/up-to-laravel-80.php';

    /**
     * @var string
     */
    public const UP_TO_LARAVEL_90 = __DIR__ . '/../../config/sets/level/up-to-laravel-90.php';

    /**
     * @var string
     */
    public const UP_TO_LARAVEL_100 = __DIR__ . '/../../config/sets/level/up-to-laravel-100.php';

    /**
     * @var string
     */
    public const UP_TO_LARAVEL_110 = __DIR__ . '/../../config/sets/level/up-to-laravel-110.php';

    /**
     * @var string
     */
    public const UP_TO_LARAVEL_120 = __DIR__ . '/../../config/sets/level/up-to-laravel-120.php';
}
